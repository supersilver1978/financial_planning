# Create variables
age = 21
years = 10

name = "John"
last_name = "Doe"
space = " "
# Print the variables

# Prints the data type of each declared variable
print(name + space +last_name)
# Using variable names in calculations
# after_ = age + years
# Updating variables using assignment
# print(after_)
# Substituting/formatting variable

# Two number values will be added

# Two string values will be concatenated

# Variable naming conventions
