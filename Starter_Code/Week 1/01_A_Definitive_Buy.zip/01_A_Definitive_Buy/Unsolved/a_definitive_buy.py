"""A Definitive Buy."""


# @TODO: Create a function that prints two messages.
# The first message should state the cost of the transaction.
# THe second message should state that the payment has been processed.
# YOUR CODE HERE


# Call the function to run the code in the function.
process_payment()
