# -*- coding: utf-8 -*-
"""Instructor Demo: Lists.

This script showcases basic operations of Python Lists.
"""
# A list in Python is a collection of ordered elements or values, separated by commas, with an index of "zero" for the first element.

# Index: 0 = "green", 1 = "blue", 2 = "red", 3 = "purple"
color_hats = ["green", "blue", "red", "purple"]


# Lists commonly hold values of the same data type or different data types.
# Lists can even hold other lists!

my_favorite_things = ["Chocolate", 9, ["beach", "mountains"], "breakfast_tacos"]
# print(my_favorite_things[2][1])
# Create a list of places where our class lives from slack responses.
# print("We are a diverse group and come from everywhere...")
where_we_live = [
    "San Francisco, CA",
    "Conway, AR",
    "Orlando, FL",
    "Buffalo, NY",
    "Chicago, IL",
    "Edison, NJ",
    "Avondale, PA",
]
where_we_live.append("Miami ,FL")
print(where_we_live)