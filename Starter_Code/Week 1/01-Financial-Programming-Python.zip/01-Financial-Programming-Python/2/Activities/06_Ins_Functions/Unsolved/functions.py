# x = 1
# y = 1e4

def sum_(x,y):
    return x + y

value = sum_(y = 1,x = 123)
print(value)
