# Percent Increase Activity

# Formulas
# Increase = Current Price - Original Price
# Percent Increase = Increase / Original x 100

# @TODO: Create float variable for original_price
# YOUR CODE HERE!

# @TODO: Create float variable for current_price
# YOUR CODE HERE!

# @TODO: Calculate difference between current_price and original_price
# YOUR CODE HERE!

# @TODO: Calculate percent_increase
# YOUR CODE HERE!

# Print original_price
print(f"Apple's original stock price was ${original_price}")

# Print current_price
print(f"Apples current stock price is ${current_price}")

# @TODO: Print percent_increase to 2 decimal places using f-string formatting
# YOUR CODE HERE!
