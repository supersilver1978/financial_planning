"""Hello Variable World."""

# 1. @TODO: Create a variable called `original_price`
# and assign it the value of `198.87`.
# YOUR CODE HERE!

# 2. @TODO: Create a variable called `current_price`
# and assign it the value `254.32`.
# YOUR CODE HERE!

# 3. @TODO: Create a variable called `increase` and assign the
# difference between the current price and the original price.
# YOUR CODE HERE!

# 4. @TODO: Divide `increase` by `original_price` and multiply that by 100.
# Then assign the results to the variable called `percent_increase`.
# YOUR CODE HERE!

# 5. @TODO: Print all of the variables.
# YOUR CODE HERE!
