"""A Definitive Buy."""


def process_payment():
    print("The total cost of this transaction will be 75 cents.")
    print("Ka-ching! Payment has been processed.")


process_payment()
